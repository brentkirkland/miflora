miflora - Library for Xiaomi Mi plant sensor
============================================

This library lets you read sensor data from a Xiaomi Mi Flora plant sensor.

It supports reading
- temperature
- moisture
- fertility
- light intensity

